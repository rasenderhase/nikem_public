<?php defined('_JEXEC') or die(); ?>
<h1><?php echo $this->gruesse; ?></h1>