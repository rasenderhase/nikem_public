<?php defined('_JEXEC') or die(); 
	$document =& JFactory::getDocument();
	$document->addCustomTag('<link rel="profile" href="http://microformats.org/profile/hcard">');
?>
<h1>
	Die iPub Administration
</h1>

<ul class="vcard">
    <li class="fn">Andreas Knees</li>
    <li class="nickname">Andi</li>
    <li class="org">nikem GmbH</li>
    <li class="tel">0711 46050208</li>
    <li><a class="url" href="http://www.nikem.de/">http://www.nikem.de/</a></li>
</ul>